// Mehta Sales API — one serverless function, JSON-RPC style: POST /api {a:'action', ...}
const { Redis } = require('@upstash/redis');
const crypto = require('crypto');

const url = process.env.UPSTASH_REDIS_REST_URL || process.env.KV_REST_API_URL;
const tok = process.env.UPSTASH_REDIS_REST_TOKEN || process.env.KV_REST_API_TOKEN;
const redis = url && tok ? new Redis({ url, token: tok }) : null;
const SECRET = process.env.AUTH_SECRET;
const OWNER_USER = (process.env.OWNER_USER || 'parth').toLowerCase();
const OWNER_PASS = (process.env.OWNER_PASS || 'apple8901').toLowerCase();

const fail = (status, error) => Object.assign(new Error(error), { status });
const b64 = (s) => Buffer.from(s).toString('base64url');
const mac = (p) => crypto.createHmac('sha256', SECRET).update(p).digest('base64url');
const sign = (d) => { const p = b64(JSON.stringify(d)); return p + '.' + mac(p); };
const same = (a, b) => a.length === b.length && crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
function verify(t) {
  try {
    const [p, s] = String(t).split('.');
    if (!same(s, mac(p))) return null;
    const d = JSON.parse(Buffer.from(p, 'base64url').toString());
    return d.exp > Date.now() ? d : null;
  } catch { return null; }
}
const hashPw = (pw) => { const salt = crypto.randomBytes(16).toString('hex'); return salt + ':' + crypto.scryptSync(pw, salt, 32).toString('hex'); };
const checkPw = (pw, st) => { const [s, h] = String(st).split(':'); return same(crypto.scryptSync(pw, s, 32).toString('hex'), h); };
const rid = () => Math.random().toString(36).slice(2, 9);

// Role presets. 'custom' lets the owner tick permissions by hand.
// add = add products, edit = edit products & change stock, del = delete, sell = reduce stock only.
const ROLES = {
  owner: { add: 1, edit: 1, del: 1, sell: 1 },
  manager: { add: 1, edit: 1, del: 1, sell: 1 },
  store: { add: 1, edit: 1, del: 0, sell: 1 },
  sales: { add: 0, edit: 0, del: 0, sell: 1 },
};

// ---------- outlets ----------
async function getOutlets() {
  let o = await redis.hgetall('outlets');
  if (!o || !Object.keys(o).length) { o = { main: { id: 'main', name: 'Main Shop' } }; await redis.hset('outlets', o); }
  return o;
}
// stock per outlet for a product (older single-quantity products belong to the first outlet)
const stockOf = (p, outs) => p.stock || { [outs.main ? 'main' : Object.keys(outs)[0]]: +p.qty || 0 };
const sum = (st) => Object.values(st).reduce((a, b) => a + (+b || 0), 0);
const allowed = (me, outs) => (me.owner || !Array.isArray(me.ol) ? Object.keys(outs) : me.ol.filter((id) => outs[id]));

async function whoAmI(req) {
  const t = (req.headers.authorization || '').replace('Bearer ', '');
  const d = verify(t);
  if (!d) throw fail(401, 'Please sign in again');
  if (d.o) return { name: OWNER_USER, owner: true, master: true, role: 'owner', add: 1, edit: 1, del: 1, sell: 1, blocked: [] };
  const u = await redis.hget('users', d.n); // permissions are read fresh on every request
  if (!u) throw fail(401, 'Account no longer exists');
  if (u.role === 'owner') return { name: u.name, owner: true, master: false, role: 'owner', add: 1, edit: 1, del: 1, sell: 1, blocked: [] };
  return { name: u.name, owner: false, master: false, role: u.role || 'custom', add: u.add, edit: u.edit, del: u.del, sell: u.sell ?? (u.edit ? 1 : 0), blocked: u.blocked || [], ol: u.outlets };
}

async function loadAll(me) {
  const rev = Number(await redis.get('rev')) || 0; // read first: a newer write just makes the next poll reload
  const outs = await getOutlets();
  const ids = allowed(me, outs);
  const [prods, dealer, users] = await Promise.all([
    redis.hgetall('products'),
    me.owner ? redis.hgetall('dealer') : null,
    me.owner ? redis.hgetall('users') : null,
  ]);
  let products = Object.values(prods || {});
  if (!me.owner) products = products.filter((p) => !me.blocked.includes(p.brand));
  products = products.map((p) => {
    const all = stockOf(p, outs), stock = {};
    ids.forEach((id) => (stock[id] = +all[id] || 0)); // only the outlets this person may see
    const r = { ...p, stock, qty: sum(stock) };
    if (me.owner) r.dealer = (dealer || {})[p.id] ?? ''; // dealer price: owner only
    return r;
  });
  const { ol, ...pub } = me;
  return {
    me: { ...pub, outlets: ids },
    rev,
    outlets: ids.map((id) => outs[id]),
    products,
    users: Object.values(users || {}).map(({ h, ...u }) => u),
  };
}

function cleanProduct(b) {
  const a = {};
  for (const [k, v] of Object.entries(b.a || {})) if (v !== '' && v != null && k.length < 30) a[k] = String(v).slice(0, 60);
  const p = {
    id: String(b.id || '').replace(/[^a-z0-9]/gi, '').slice(0, 20),
    cat: String(b.cat || '').slice(0, 40),
    brand: String(b.brand || '').trim().slice(0, 40),
    model: String(b.model || '').trim().slice(0, 80),
    a,
    mrp: b.mrp === '' || b.mrp == null ? '' : Number(b.mrp) || 0,
  };
  if (!p.id || !p.cat || !p.brand || !p.model) throw fail(400, 'Brand and model are required');
  return p;
}

const logEv = (me, act, p, from, to, outlet) =>
  redis.lpush('log', { t: Date.now(), who: me.name, act, outlet: outlet || '', cat: p.cat, brand: p.brand, model: p.model, from, to });

const actions = {
  async login(req, b) {
    const u = String(b.u || '').trim().toLowerCase(), p = String(b.p || '').trim();
    let token = null;
    if (u === OWNER_USER && p.toLowerCase() === OWNER_PASS) token = sign({ o: 1, exp: Date.now() + 30 * 864e5 });
    else {
      const x = await redis.hget('users', u);
      if (x && checkPw(p, x.h)) token = sign({ n: u, exp: Date.now() + 30 * 864e5 });
    }
    if (!token) { await new Promise((r) => setTimeout(r, 500)); throw fail(401, 'Wrong username or password'); }
    const me = await whoAmI({ headers: { authorization: token } });
    return { token, ...(await loadAll(me)) };
  },
  async load(req, b, me) { return loadAll(me); },
  async rev(req) {
    if (!verify((req.headers.authorization || '').replace('Bearer ', ''))) throw fail(401, 'Please sign in again');
    return { rev: Number(await redis.get('rev')) || 0 };
  },
  async log(req, b, me) {
    if (!me.owner) throw fail(403, 'Owner only');
    return { log: await redis.lrange('log', 0, 1999) };
  },
  async saveP(req, b, me) {
    const outs = await getOutlets();
    const ids = allowed(me, outs);
    const p = cleanProduct(b.p || {});
    const old = await redis.hget('products', p.id);
    const sellOnly = !me.owner && !!old && !me.edit && !!me.sell; // Sales Officer: may only reduce stock
    if (!me.owner) {
      if (!sellOnly && (old ? !me.edit : !me.add)) throw fail(403, 'You do not have permission to do that');
      if (sellOnly && (['cat', 'brand', 'model', 'mrp'].some((k) => old[k] !== p[k]) || JSON.stringify(old.a) !== JSON.stringify(p.a))) throw fail(403, 'You can only reduce stock');
      if (me.blocked.includes(p.brand) || (old && me.blocked.includes(old.brand))) throw fail(403, 'That brand is blocked for you');
      if (!ids.length) throw fail(403, 'You have no outlet access');
    }
    const oldStock = old ? stockOf(old, outs) : {};
    const sub = b.p.stock && typeof b.p.stock === 'object' ? b.p.stock : {};
    const stock = { ...oldStock };
    for (const id of ids) if (sub[id] !== undefined) stock[id] = Math.max(0, parseInt(sub[id]) || 0);
    if (sellOnly && Object.keys(stock).some((id) => (+stock[id] || 0) > (+oldStock[id] || 0))) throw fail(403, 'You can only reduce stock');
    p.stock = stock;
    p.qty = sum(stock);
    await redis.hset('products', { [p.id]: p });
    if (!old) {
      const withStock = Object.keys(stock).filter((id) => stock[id] > 0);
      if (!withStock.length) await logEv(me, 'Added', p, null, 0, '');
      for (const id of withStock) await logEv(me, 'Added', p, null, stock[id], outs[id]?.name);
    } else {
      for (const id of new Set([...Object.keys(oldStock), ...Object.keys(stock)])) {
        const f = +oldStock[id] || 0, t = +stock[id] || 0;
        if (f !== t) await logEv(me, t > f ? 'Stock increased' : 'Stock decreased', p, f, t, outs[id]?.name);
      }
      if (['cat', 'brand', 'model', 'mrp'].some((k) => old[k] !== p[k]) || JSON.stringify(old.a) !== JSON.stringify(p.a)) await logEv(me, 'Details edited', p, null, null, '');
    }
    await redis.ltrim('log', 0, 1999);
    if (me.owner && b.p.dealer !== undefined) {
      if (b.p.dealer === '' || b.p.dealer == null) await redis.hdel('dealer', p.id);
      else await redis.hset('dealer', { [p.id]: Number(b.p.dealer) || 0 });
    }
    await redis.incr('rev');
    return loadAll(me);
  },
  async delP(req, b, me) {
    const id = String(b.id || '');
    const old = await redis.hget('products', id);
    if (!me.owner && (!me.del || (old && me.blocked.includes(old.brand)))) throw fail(403, 'You do not have permission to delete');
    await redis.hdel('products', id);
    await redis.hdel('dealer', id);
    if (old) { await logEv(me, 'Deleted', old, +old.qty || 0, 0, ''); await redis.ltrim('log', 0, 1999); }
    await redis.incr('rev');
    return loadAll(me);
  },
  async saveO(req, b, me) {
    if (!me.owner) throw fail(403, 'Owner only');
    const outs = await getOutlets();
    const name = String(b.name || '').trim().slice(0, 40);
    if (!name) throw fail(400, 'Enter an outlet name');
    const id = b.id && outs[b.id] ? b.id : 'o' + rid();
    if (Object.values(outs).some((o) => o.id !== id && o.name.toLowerCase() === name.toLowerCase())) throw fail(409, 'An outlet with that name exists');
    await redis.hset('outlets', { [id]: { id, name } });
    await redis.incr('rev');
    return loadAll(me);
  },
  async delO(req, b, me) {
    if (!me.owner) throw fail(403, 'Owner only');
    const outs = await getOutlets(), id = String(b.id || '');
    if (!outs[id]) throw fail(404, 'Outlet not found');
    if (Object.keys(outs).length < 2) throw fail(400, 'You need at least one outlet');
    const prods = Object.values((await redis.hgetall('products')) || {});
    if (prods.some((p) => (+stockOf(p, outs)[id] || 0) > 0)) throw fail(409, 'This outlet still has stock. Set it to zero first.');
    await redis.hdel('outlets', id);
    await redis.incr('rev');
    return loadAll(me);
  },
  async saveU(req, b, me) {
    if (!me.owner) throw fail(403, 'Owner only');
    const u = b.u || {};
    const name = String(u.name || '').trim();
    if (!/^[\w .-]{1,30}$/.test(name)) throw fail(400, 'Username: letters, numbers, space . _ - (max 30)');
    const key = name.toLowerCase(), oldKey = u.old ? String(u.old).toLowerCase() : '';
    if (key === OWNER_USER || (key !== oldKey && (await redis.hget('users', key)))) throw fail(409, 'That username is taken');
    const prev = oldKey ? await redis.hget('users', oldKey) : null;
    const role = ROLES[u.role] ? u.role : 'custom';
    if ((role === 'owner' || (prev && prev.role === 'owner')) && !me.master) throw fail(403, 'Only the main owner can manage Owner accounts');
    const pr = ROLES[role] || { add: +!!u.add, edit: +!!u.edit, del: +!!u.del, sell: +!!u.sell };
    const pw = String(u.pw || '').trim();
    if (!pw && !prev) throw fail(400, 'Password required');
    await redis.hset('users', {
      [key]: {
        name, h: pw ? hashPw(pw) : prev.h, role, add: pr.add, edit: pr.edit, del: pr.del, sell: pr.sell,
        blocked: Array.isArray(u.blocked) ? u.blocked.map(String) : [],
        outlets: Array.isArray(u.outlets) ? u.outlets.map(String) : null, // null = all outlets
      },
    });
    if (oldKey && oldKey !== key) await redis.hdel('users', oldKey);
    await redis.incr('rev');
    return loadAll(me);
  },
  async delU(req, b, me) {
    if (!me.owner) throw fail(403, 'Owner only');
    const target = await redis.hget('users', String(b.name || '').toLowerCase());
    if (target && target.role === 'owner' && !me.master) throw fail(403, 'Only the main owner can remove Owner accounts');
    await redis.hdel('users', String(b.name || '').toLowerCase());
    await redis.incr('rev');
    return loadAll(me);
  },
};

module.exports = async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  try {
    if (req.method !== 'POST') throw fail(405, 'POST only');
    if (!SECRET) throw fail(500, 'Server setup: AUTH_SECRET environment variable is missing');
    if (!redis) throw fail(500, 'Server setup: database not connected (add Upstash Redis in Vercel → Storage)');
    const b = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : req.body || {};
    const fn = actions[b.a];
    if (!fn) throw fail(400, 'Unknown action');
    const me = b.a === 'login' || b.a === 'rev' ? null : await whoAmI(req);
    res.status(200).json(await fn(req, b, me));
  } catch (e) {
    res.status(e.status || 500).json({ error: e.status ? e.message : 'Server error' });
    if (!e.status) console.error(e);
  }
};
